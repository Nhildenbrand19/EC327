#include "Stack.h"

using namespace std;

#define MAX_SIZE 100

template <typename T>
Stack<T>::Stack() //constructor
{
    size = 0;
    elements = new T[MAX_SIZE];
}

template <typename T>
bool Stack<T>::isEmpty() const //returns true if stack is empty, false otherwise
{
    if (size == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

template <typename T>
void Stack<T>::push(T value) //add a new item of type T and value value to the stack if there is still space on the stack
{
    elements[size++] = value;
}

template <typename T>
T Stack<T>::pop() //return top element on the stack, remove the returned item from stack
{
    return elements[--size];
}

template <typename T>
int Stack<T>::getSize() const //return the size of the stack
{
    return size;
}

#include "Stack.h"
#include "Stack.cpp"
#include <iostream>

using namespace std;

//returns true if the parentheses in the expression are correct, false otherwise.
bool parCheck(const string &expression)
{
    Stack<char> T;
    char ch;
    for (int i = 0; i < expression.length(); i++)
    {
        char c = expression[i];
        if (c == '(' || c == '{')
        {
            T.push(c);
        }
        else if(c == ')' || c == '}')
        {
            if (T.isEmpty()) {
                return false;
            }
            switch (c)
            {
                case ')':
                    ch = T.pop();
                    if (ch == '{') {
                        return false;
                    }
                    break;
                case '}':
                    ch = T.pop();
                    if (ch == '(') {
                        return false;
                    }
                    break;
            }
        } else if (!isdigit(c) && c != '+' && c != '-' && c != '*' && c != '/' && c != ' ') {
            cout << "Unknown character" << endl;
            //return false;
        }
    }
    return T.isEmpty();
}

int main()
{
    string expression;
    cout << "Enter an expression: ";
    getline(cin, expression);
    if (parCheck(expression))
        cout << "Correct Expression" << endl;
    else
        cout << "Incorrect Expression" << endl;
}

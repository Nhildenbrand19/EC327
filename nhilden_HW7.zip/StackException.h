#ifndef STACKEXCEPTION_H
#define STACKEXCEPTION_H
#include <stdexcept>

class StackException : std::exception
{
public:
  virtual const char * what() const throw();
};

#endif

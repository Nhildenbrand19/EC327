#include <iostream>
#include "StackException.h"
using namespace std;

const char *StackException::what() const throw(){
    return "There are no items on stack!";
}

#include <iostream>
#include <vector>
#include <string>

//add other libraries if needed

using namespace std;

//returns a vector of strings that represent operands or numbers
//implement your function here
vector<string> split(const string &expression){
  vector<string> result;
  string numStr;

  // loop over the whole expression
  for (int i = 0;i < expression.length(); i++){
    char ch = expression[i];
    if (isdigit(ch)){
      numStr.append(1, ch); //add digit to number
    }
    else{
      if (numStr.size() > 0){
        result.push_back(numStr); //number to vector
        numStr = "";
      }
      // if the current character is not space and a valid operator;
      if (!isspace(ch) && (ch == '+' || ch == '*')){
        string s;
        s.append(1, ch);
        result.push_back(s);
      }
    }
  }
  // Store the last number
  if (numStr.size() > 0){
    result.push_back(numStr);
  }
  return result;
}

int main()
{
  //test code:
  //ask the user to enter an expression
  string expression;
  cout << "Enter an expression: ";
  getline(cin, expression);
  //call the split function
  vector<string> result = split(expression);

  //add more test cases if needed
  for (vector<string>::iterator it = result.begin();it != result.end();it++){
    cout << *it << endl;
  }

  return 0;
}

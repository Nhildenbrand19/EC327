#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

// use long int to increase precision and avoiding integer overflow
long int factorial(int n)
{
    if (n == 0 || n == 1)
        return 1;
    else
        return n * factorial(n - 1);
}

// use long double to increase precision
long double ExpTaylor(int x, int n)
{
    if (n == 1)
        return 1;
    else
        return (pow(x, n - 1) / factorial(n - 1)) + ExpTaylor(x, n - 1);
}

// function to find minimum n, such that taylor expansion value and exp(x) has at most 0.01 difference
int minN(int x) {
    long double expVal = exp(x);
    long double sum = 0.0;

    // run a loop starting from 1
    for (int i=1;;i++) {
        // calculate the current value of taylor
        sum = sum + pow(x,i-1) / factorial(i-1);
        // if the dif is at most 0.01, return i
        if (expVal - sum <= 0.01) {
            return i;
        }
    }
}

int main()
{
    int x;
    int n;

    cout << "Enter x: ";
    cin >> x;

    cout << "Enter n: ";
    cin >> n;

    cout << "ExpTaylor Result: " << setprecision(3)  << ExpTaylor(x,n) << endl;
    cout << "exp(x) result: "  << setprecision(3) << fixed << exp(x) << endl;
    cout << "Minimum n for a difference of at most 0.01: " << minN(x) << endl;
    return 0;
}

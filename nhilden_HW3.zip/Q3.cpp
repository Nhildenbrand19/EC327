#include <iostream>
#include <cmath>
#include <cstdlib>
using namespace std;

double guessSqrt(double num)
{
    // use initial value of last guess as 1
    double lastGuess = 1;
    // compute the next guess value
    double nextGuess = (lastGuess + (num / lastGuess)) / 2;

    // keep looping till the absolute difference is greater than or equal to 0.001
    while (abs(nextGuess - lastGuess) >= 0.001)
    {
        // make the last guess as the next guess computed earlier
        lastGuess = nextGuess;
        // compute the new value of next guess
        nextGuess = (lastGuess + (num / lastGuess)) / 2;
    }
    return nextGuess;
}
int main()
{
    double num;
    cout << "Enter a positive number: ";
    cin >> num;
    // print the absolute difference between sqrt(num) and guessSqrt(num)
    cout << "The absolute difference between the correct square root and the function's result is " << abs(sqrt(num) - guessSqrt(num)) << endl;
    return 0;
}

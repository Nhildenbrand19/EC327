#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
    cout << "Welcome to EC327-Lottery!" << endl;
    srand(time(0));
    bool hasWon = false;

    // keep looping till the user wins ( full or partial award )
    while (!hasWon)
    {
        int num = rand() % 19; // generate a random number between 0 to 19

        int guess;
        // input a number from the user
        cout << "Please enter a number between 0-19: ";
        cin >> guess;

        // if the user input is not between 0-19 print message
        if (guess < 0 || guess > 19)
        {
            cout << "You need to enter a number between 0-19." << endl
                 << endl;
        }
        // if the user input is in valid range
        else
        {
            // if the number is equal to guess, print message
            if (num == guess)
            {
                cout << "CONGRATULATIONS!" << endl;
                hasWon = true;
            }
            else
            {
                // create a copy of guess
                int copyGuess = guess;
                // flag to denote if a partial match is found
                bool isPartialMatch = false;
                // loop over all the digits of guess
                while (copyGuess > 0)
                {
                    // get the current digit of guess
                    int guessDigit = copyGuess % 10;
                    // create a copy of random num generated
                    int copyNum = num;
                    // for each digit of guess, compare with all the digits of random num
                    while (copyNum > 0)
                    {
                        // get the current digit of random num
                        int numDigit = copyNum % 10;
                        // if the 2 digits are equal
                        if (numDigit == guessDigit)
                        {
                            // partial match is found
                            isPartialMatch = true;
                            // user has partially won the game
                            hasWon = true;
                            break; // break out of the loop
                        }
                        // remove the last digit from the number
                        copyNum /= 10;
                    }
                    // remove the last digit from guess
                    copyGuess /= 10;
                }
                // print a message if partial match is found
                if (isPartialMatch)
                {
                    cout << "Partial Award!" << endl;
                }
            }
            // print a correct number and guessed number at the end of the loop
            cout << "The correct number is " << num << ", you guessed " << guess << "." << endl
                 << endl;
        }
    }
    return 0;
}

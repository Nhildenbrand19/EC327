#include <iostream>
#include <fstream>
#include <map>
#include <string>

// Include any additional libraries you'd like up here...
// Remember your must use map as your primary data structure!

using namespace std;

// Define any helper functions you like up here...

int main(int argc, char * argv[]) {
	// Q4a
	// Declare your map here!
	map<int,string> lib;

	int num;
	string book_name;

	cout << "Type in the details for a book and hit enter to add to the catalog." << endl;
	cout << "Alternatively, type \"-1\" and hit enter to exit this program." << endl;

	// Q4b
	while(true) {

    	cout << "Insert the book's ISBN: " << endl;
    	cin >> num;

    	if(num == -1) {
    		break;
    	}

    	if (lib.find(num) != lib.end())
    	{
    	    cout << "The book with this ISBN is already in the library!" << endl;
    	    continue;
    	}

    	cout << "Insert the book's title: " << endl;
    	cin >> book_name;

    	lib[num] = book_name;
    }

	// Q4c
	// Do file handling here
	ofstream myfile;
  myfile.open ("library_list.txt");

    map<int, string>::iterator itr;
    for (itr = lib.begin() ; itr != lib.end() ; itr++) {
        myfile << itr->second << endl;
    }

    myfile.close();
	return 0;
}

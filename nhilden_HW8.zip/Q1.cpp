#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
#include <bits/stdc++.h>
//Include other libraries as needed

using namespace std;


string reverseString(const string &s1){
    //Write reverseString function here
    static int index = 0;
    string temp = "";
    int len = s1.length();

    index++;
    //throw an exception if the size of the word exceeds 15
    if (len > 15)
      throw index;

    for (int i = 0; i < len; i++) {
        temp = s1[i] + temp;
    }
    return temp;
}


int main()
{
    string filename = "words.txt";
    string words;
    //Write program here
    ifstream input;
    ofstream output;
    input.open(filename.c_str());
    output.open("reversewords.txt");

    while(getline(input, words)) {
        try {
            output << reverseString(words) << endl;
        }
        //catchexception
        catch (int lineNo){
            //print the caught exception message
            cout << "Error: line " << lineNo << ": exceeds 15 characters, skipping" << endl;
        }
    }

    output.close();
    input.close();

    return 0;
}

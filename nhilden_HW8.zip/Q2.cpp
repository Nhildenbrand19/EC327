#include <iostream>
#include <sstream>
#include "Q2.h"
//Include other libraries if needed
//
//
//

using namespace std;

//Implement Rectangle functions here
Rectangle::Rectangle(int height, int width, int x, int y){
    this->width = width;
    this->height = height;
    this->x = x;
    this->y = y;
}

int Rectangle::getHeight() const{
    return height;
}

int Rectangle::getWidth() const{
    return width;
}


int Rectangle::getOverlapArea(const Rectangle & r) const {
    //Checks whether the Rectangle object overlaps with another Rectangle
    //object (Rectangle &r) on the plane. Function returns 0 if there is no
    //overlap, and returns the area of the overlap otherwise.
    string coordinates = r.getCoordinates();
    int find = coordinates.find(",");

    int x1 = stoi(coordinates.substr(0, find));
    int y1 = stoi(coordinates.substr(find + 1, coordinates.size() - 1));

    int xOverlap = 0, yOverlap = 0;

    //if x is inside r
    if(x < x1 && x1 < x + width)
        xOverlap = x + width - x1;

    else if(x == x1)
        xOverlap = min(width, r.getWidth());
    //if x1 is inside this rectangle
    else if(x > x1 && x < x1 + r.getWidth())
        xOverlap = x1 + width - r.getWidth();

    //if y is inside r
    if(y < y1 && y1 < y + height)
        yOverlap = y + height - y1;

    else if(y == y1)
        yOverlap = min(height, r.getHeight());
    //if y1 is inside this rectangle
    else if(y > y1 && y < y1 + r.getHeight())
        yOverlap = y1 + height - r.getHeight();

    return xOverlap * yOverlap;
}

string Rectangle::getCoordinates() const {
  //returns the coordinates of the lower left corner of the Rectangle in a
  //string format. For example, if x=1 and y=2, it will return “1,2”.

  stringstream ss;
  ss<< this->x;
  ss<< ",";
  ss<< this->y;
  string str = ss.str();
  return str;
}



//Hint:
  //To convert integers to strings, you can use stringstream if you like:
  //int a = 10;
  //stringstream ss;
  //ss << a;
  //string str = ss.str();




int main()
{
  //Uncomment once Rectangle class is created
  //DO NOT modify the test code

  Rectangle r1(4,3,0,0), r2(2,1,3,0);  // (width, height, x, y)

  cout << "Overlap area of a rectangle with height "
       << r1.getHeight() << " and width " << r1.getWidth()
       << " at coordinates " << r1.getCoordinates()
       << " and a rectangle with height "
       << r2.getHeight() << " and width " << r2.getWidth()
       << " at coordinates " << r2.getCoordinates()
       << " is: " << r1.getOverlapArea(r2) << endl;

  //This code should print on the console:
  //Overlap area of a rectangle with height 3 and width 4 at coordinates 0,0 and a rectangle with height 1 and width 2 at coordinates 3,0 is 1


  //Put your additional test code here
  /*Follow the sample run:
  "Enter height, width, x coordinate, and y coordinate of a rectangle:"
  <user enters four numbers separated by spaces and hits enter>
  Enter height, width, x coordinate, and y coordinate of another rectangle:
  <user enters four numbers separated by spaces and hits enter>
  Overlap area: ... */
  int height, width, x, y;


  cout << "Enter height, width, x coordinate, and y coordinate of a rectangle:" << endl;
  cin >> height >> width >> x >> y;
  Rectangle r3(height, width, x, y);

  cout << "Enter height, width, x coordinate, and y coordinate of another rectangle:" << endl;
  cin >> height >> width >> x >> y;
  Rectangle r4(height, width, x, y);
  //print the overlapping area
  cout << "Overlap area of a rectangle with height "
       << r3.getHeight() << " and width " << r3.getWidth()
       << " at coordinates " << r3.getCoordinates()
       << " and a rectangle with height "
       << r4.getHeight() << " and width " << r4.getWidth()
       << " at coordinates " << r4.getCoordinates()
       << " is: " << r3.getOverlapArea(r4) << endl;
  return 0;
}

#include <iostream>
#include <cmath>

using namespace std;

char MostFrequentChar(char word[], int size) {
    // initialize the values
    char mostFreqCharacter = '\0';
    int maxCount = -1;
    // loop over the whole char array
    for (int i=0; i < size; i++) {
        // initialize the count to 0
        int count = 0;
        // for each element in array, compare with all other elements and get the count
        for (int j=0; j < size; j++) {
            if (word[i] == word[j]) {
                count++;
            }
        }
        // if the count of the current character is more than the maxCount, update the maxCount and the mostFreqCharacter
        if (count > maxCount) {
            maxCount = count;
            mostFreqCharacter = word[i];
        }
    }
    return mostFreqCharacter;
}

char MostFrequentCharCaseInsensitive(char word[], int size) {
    char mostFreqCharacter = '\0';
    int maxCount = -1;
    // loop over the whole char array
    for (int i=0; i < size; i++) {
        // initialize the count to 0
        int count = 0;
        // for each element in array, compare with all other elements and get the count
        for (int j=0; j < size; j++) {
            // perform a case-insensitive check, the absolute difference between same lower and uppercase character is always 32
            if (word[i] == word[j] || abs(word[i] - word[j]) == 32) {
                count++;
            }
        }
        if (count > maxCount) {
            maxCount = count;
            mostFreqCharacter = word[i];
        }
    }
    return mostFreqCharacter;
}

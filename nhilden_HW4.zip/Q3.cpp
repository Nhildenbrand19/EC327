#include <iostream>
#include <algorithm>

using namespace std;

const int rowSize1 = 4;
const int columnSize1 = 3;
const int rowSize2 = 3;
const int columnSize2 = 2;

void matrixMultiply(int matrix1[][columnSize1], int matrix2[][columnSize2], int result[][columnSize2])
{
    // initialize elements of result to 0.
    for (int i = 0; i < rowSize1; ++i)
    {
        for (int j = 0; j < columnSize2; ++j)
        {
            result[i][j] = 0;
        }
    }
    // loop over rows of first matrix
    for (int i = 0; i < rowSize1; ++i)
    {
        // loop over columns of second matrix
        for (int j = 0; j < columnSize2; ++j)
        {
            // loop over the column of first matrix
            for (int k = 0; k < columnSize1; ++k)
            {
                // perform multiplication and store the result 
                result[i][j] += matrix1[i][k] * matrix2[k][j];
            }
        }
    }
}

int main()
{

    cout << "Write a 4x3 integer matrix and a 3x2 integer matrix: " << endl;
    int matrix1[rowSize1][columnSize1];
    int matrix2[rowSize1][columnSize2];
    int result[rowSize1][columnSize2];

    for (int i = 0; i < rowSize1; i++)
        for (int j = 0; j < columnSize1; j++)
            cin >> matrix1[i][j];

    for (int i = 0; i < rowSize2; i++)
        for (int j = 0; j < columnSize2; j++)
            cin >> matrix2[i][j];

    matrixMultiply(matrix1, matrix2, result);

    // display the matrix
    for (int i = 0; i < rowSize1; i++) {
        for (int j = 0; j < columnSize2; j++) {
            cout << result[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}

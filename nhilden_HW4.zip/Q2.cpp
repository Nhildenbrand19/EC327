#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>

using namespace std;

int *QuadCapacity(int *list, int size)
{
    // create a new array of 4*size
    int *quadArr = new int(size*4);
    // copy all the elements of input array
    for (int i = 0; i < size; i++) {
        quadArr[i] = list[i];
    }
    // intitialize all the other elements to 0
    for (int i=0; i < size*4; i++) {
        quadArr[i] = 0;
    }
    return quadArr;
}

int main()
{
    int arr[] = {5, 21, 32, 45};
    int *newArr = QuadCapacity(arr, 4);
    string filename;
    int count = 0, val = 0;
    // read a filename from the user
    cout << "Enter a filename: ";
    cin >> filename;
    ifstream inFile (filename.c_str());

    // loop till there are no more integers
    while (inFile >> val) {
        // store the read value in the array
        newArr[count++] = val;
    }

    // display what is in the file 
    for (int i=0; i < count; i++) {
        cout << newArr[i] << " ";
    }
    cout << endl;
    inFile.close();
    return 0;
}

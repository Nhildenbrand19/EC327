#include <iostream>
#include <bits/stdc++.h>
#include <cstring>

using namespace std;

// Function given
char* largestCommonSubstr(const char s1[ ], const char s2[ ])
{
    // Find length of both.
    int first = sizeof(s1)/sizeof(s1[0]);
    int second = sizeof(s2)/sizeof(s2[0]);
    // Stores result
    int result = 0;
    // Stores ending point of longest common substring
    int end;
    // Stores length of two consecutive rows at a time.
    int len[2][second];
    // Represent current row
    int currRow = 0;
    // Create a new char variable to return at the end of the Function
    char* sub = new char[first];
    // For values of i and j, make a loop
    for (int i = 0; i <= first; i++) {
        for (int j = 0; j <= second; j++) {
            if (i == 0 || j == 0) {
                len[currRow][j] = 0;
            }
            else if (s1[i - 1] == s2[j - 1]) {
                len[currRow][j] = len[i-1][j - 1] + 1;
                if (len[currRow][j] > result) {
                    result = len[currRow][j];
                    end = i - 1;
                }
            }
            else {
                len[currRow][j] = 0;
            }
        }
        // Make the previous row the current row
        currRow = 1 - currRow;
    }
    // If there is nothing in common, print none.
    if (result == 0) {
      cout << "none" << endl;
      return 0;
    }
    // Return Longest common substring. This isnt working for some reason.
    return sub;
}

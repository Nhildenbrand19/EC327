#include "Person.h"
#include <iostream>
#include <string>
#include <cstring>

using namespace std;

//no arg constructor
Person::Person()
{
    weight = 0;
    height = 0;
    name = new char[100];
    strcpy(name,"");
}

//initialzes objects
Person::Person(double newWeight, double newHeight, char *newName)
{
    weight = newWeight;
    height = newHeight;
    name = new char[100];
    strcpy(name, newName);
}

//set function for weight
void Person::setWeight(double weight)
{
    this->weight = weight;
}

//get function for weight
double Person::getWeight()
{
    return weight;
}

//set function for height
void Person::setHeight(double height)
{
    this->height = height;
}

//get function for height
double Person::getHeight()
{
    return height;
}

//set fuction for name
void Person::setName(char name[])
{
    strcpy(this->name, name);
}

//get pointer function for name
char *Person::getName()
{
    return name;
}

//returns the height and weight ratio
double Person::getRatio()
{
    double ratio = (height ) / (weight) ;
    return ratio;
}

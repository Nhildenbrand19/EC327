#include <iostream>
#include <iomanip>
#include <string.h>
#include "Person.h"

using namespace std;

// function to sort the Person array based on height-weight ratio
void sort(Person arr[], int n)
{
    // loop from start till end of the array
    for (int i = 0; i < n - 1; i++)
    {
        // loop from start till n-i-1 index of array
        for (int j = 0; j < n - i - 1; j++)
        {
            // if ratio of jth index is less than ratio of (j+1)th index, swap the person objects
            if (arr[j].getRatio() < arr[j + 1].getRatio())
            {
                Person temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}

int main()
{
    int N;
    // read the value of N
    cin >> N;
    double weight, height;
    string name;
    Person *arr = new Person[N];
    for (int i = 0; i < N; i++)
    {
        // read the weight, height and name of the person
        cin >> weight;
        cin >> height;
        cin >> name;
        char nameArr[100];
        strcpy(nameArr, name.c_str());
        // create a person object and put it in the array
        arr[i] = Person(weight, height, nameArr);
    }
    // sort the array based on the ratio
    sort(arr, N);
    // display the array in descending order of ratio
    for (int i = 0; i < N; i++)
    {
        Person p = arr[i];
        // print upto 3 decimal places
        cout << p.getName() << " " << fixed << setprecision(3) << p.getRatio() << endl;
    }

}

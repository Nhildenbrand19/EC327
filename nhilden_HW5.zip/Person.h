#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <string>
using namespace std;

class Person
{
private:
    double weight;
    double height;
    char *name;

public:
    //no arg constructor
    Person();

    //initialzes objects
    Person(double weight, double height, char name[]);

    //set function for weight
    void setWeight(double weight);

    //get function for weight
    double getWeight();

    //set function for height
    void setHeight(double height);

    //get function for height
    double getHeight();

    //set fuction for name
    void setName(char name[]);

    //get pointer function for name
    char *getName();

    //returns the height and weight ratio
    double getRatio();
};

#endif

#include "FunString.h"
#include <iostream>
#include <string>
#include <cstring>
#include <algorithm>

using namespace std;

//constructor
FunString::FunString(char chars[], int size)
{
    // add the characters in the input arr to the string
    for (int i=0;i<size;i++) {
        str+=chars[i];
    }
}

//appends n copies ch to string but im not sure what string should be
FunString FunString::append(int n, char ch)
{
    // append character ch, n times to the string
    for (int i=1; i<n; i++) {
        str+=ch;
    }
    return *this;
}

//assigns first n number of characters in s into string
FunString FunString::assign(FunString s, int n)
{
    // assign first n characters of FunString s to current string
    for (int i=0; i<n; i++) {
        str[i] = s.str[i];
    }
    return *this;
}

//return value 1,0, or -1 based on this string compared to s
int FunString::compare(FunString s) const
{
    // use the string compare function
    return str.compare(s.str);
}

//compares with s(index, index+1...)
int FunString::compare(int index, int n, FunString s) const
{
    return str.compare(index, n, s.str);
}


//returns pointer to char array that has same character as this string
char * FunString::data() const
{
    // convert string to char* and return
    return (char *)str.c_str();
}

//returns true if anagram with s
bool FunString::isAnagram(const FunString &s) const
{
    // if the length of 2 strings is not equal return false
    if (str.length() != s.str.length()) {
        return false;
    }
    // create copy of the 2 strings
    string copy1 = str;
    string copy2 = s.str;
    // sort both the strings
    sort(copy1.begin(), copy1.end());
    sort(copy2.begin(), copy2.end());
    // the strings are anagram only if the corresponding sorted strings are equal
    return copy1 == copy2;
}

// returns common suffix of string with s, if none return empty string
FunString FunString::commonSuffix(const FunString &s) const
{
    int lenSuffix = 0;
    int len1 = str.length() - 1;
    int len2 = s.str.length() - 1;
    // loop till either length of the strings becomes 0 and the character at the end is equal in both the strings
    while (len1 >= 0 && len2 >= 0 && str[len1] == s.str[len2]) {
        // reduce the length after each iteration
        len1--;
        len2--;
        // increase the length of the suffix
        lenSuffix++;
    }
    // create a character array for suffix
    char suffixArr[lenSuffix];
    // loop over the length of the suffix
    for (int i=0; i < lenSuffix; i++) {
        // copy the characters from current string to suffix string
        suffixArr[i] = str[str.length()-lenSuffix+i];
    }
    // create object of FunString class
    FunString suffix(suffixArr, lenSuffix );
    return suffix;
}

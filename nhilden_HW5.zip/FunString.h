#ifndef FUNSTRING_H
#define FUNSTRING_H

#include <iostream>
#include <string>
using namespace std;

class FunString
{
private:
    string str;
public:
    //constructor
    FunString(char chars[], int size);

    //appends n copies ch to string
    FunString append(int n, char ch);

    //assigns first n number of characters in s into string
    FunString assign(FunString s, int n);

    //return value 1,0, or -1 based on this string compared to s
    int compare(FunString s) const;

    //compares with s(index, index+1...)
    int compare(int index, int n, FunString s) const;

    //returns pointer to char array that has same character as this string
    char * data() const;

    //returns true if anagram with s
    bool isAnagram(const FunString &s) const;

    // returns common suffix of string with s, if none return empty string
    FunString commonSuffix(const FunString &s) const;
};

#endif

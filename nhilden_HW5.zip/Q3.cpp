#include <iostream>
#include <string>
#include <fstream>

using namespace std;

void findExpression(int N, string &expr)
{
    ifstream myfile("words.txt");
    ofstream ofile("output.txt");
    // check if the file is open
    if (myfile.is_open())
    {
        // read N string from words.txt file
        for (int i=0; i<N; i++) {
            string word;
            // read 1 word
            myfile >> word;
            // check if the expr is present inside the word
            if (word.find(expr) != string::npos) {
                // if present write the word to the output file
                ofile << word << endl;
            }
        }
        // close the input as well as output file
        myfile.close();
        ofile.close();
    }
    else
    {
        cout << "words.txt not in directory" << endl;
    }
}
